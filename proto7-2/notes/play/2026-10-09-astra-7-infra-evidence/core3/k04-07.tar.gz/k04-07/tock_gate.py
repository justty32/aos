import sys,os,json,signal,time
from pathlib import Path
sys.path.insert(0,'/home/lorkhan/repo/simple_tools/aos-wt/R/proto7-2/lib')
import aos7_proc,aos7_tock
root=Path(sys.argv[1]); original=aos7_proc._signal; armed=True
def gate(groups,sig):
    global armed
    if armed and sig==signal.SIGTERM:
        armed=False
        (root/'signal-entered.json').write_text(json.dumps({'groups':sorted(groups),'at':time.monotonic()}))
        until=time.monotonic()+20
        while not (root/'signal-release').exists() and time.monotonic()<until:time.sleep(.005)
    original(groups,sig)
aos7_proc._signal=gate
sys.exit(aos7_tock.main([str(root),'a']))
