import importlib.util, os, time
from pathlib import Path
s=importlib.util.spec_from_file_location('original_hooks', '/home/lorkhan/repo/simple_tools/aos-wt/R/proto7-2/tests/_hooks.py')
h=importlib.util.module_from_spec(s); s.loader.exec_module(h)
inject=h.inject
def test_point(name):
    h.test_point(name)
    if name == 'runner-before-popen':
        gate=Path(os.environ['AOS7_TEST_CORE3_GATE'])
        gate.with_suffix('.entered').write_text(str(os.getpid()))
        while not gate.exists(): time.sleep(.01)
