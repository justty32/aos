import datetime,os,pathlib
Real=datetime.datetime
class QAClock(Real):
 @classmethod
 def now(cls,tz=None):
  t=Real.now(tz)
  try: delta=float(pathlib.Path(os.environ['QA_CLOCK_OFFSET']).read_text())
  except (KeyError,OSError,ValueError):delta=0
  return t-datetime.timedelta(seconds=delta)
datetime.datetime=QAClock
