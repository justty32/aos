import errno,os
def test_point(name): pass
def inject(op,path):
 if op=="open" and str(path)==os.environ.get("QA_EIO_PATH"): raise OSError(errno.EIO,"QA injected EIO")
