import os,signal,time,json,pathlib
signal.signal(signal.SIGTERM,signal.SIG_IGN)
p=pathlib.Path(os.environ['AOS7_TASK'])/'ready.json'
p.write_text(json.dumps({'pid':os.getpid(),'run':int(os.environ['AOS7_RUN'])}))
while True:time.sleep(.02)
