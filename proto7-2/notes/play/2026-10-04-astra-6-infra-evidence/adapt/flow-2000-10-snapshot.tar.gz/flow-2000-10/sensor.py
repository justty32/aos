import os,sys
sys.path[:0]=['/home/lorkhan/repo/simple_tools/aos/proto7-2/lib', '/home/lorkhan/repo/simple_tools/aos/proto7-2/modules/tools']
from aos7_fs import write_json,read_json
from aos7_taskside import wait_tock
t=os.environ['AOS7_TASK']; last=0;seq=(read_json(t+'/state.json') or {}).get('seq',0)
while True:
 last=wait_tock(t,last,poll=.001);seq+=1
 write_json(t+'/state.json',{'seq':seq})
 write_json('out/temp.json',{'v':1,'round':last,'seq':seq,'value':{'x':801,'other':'omitted'}})
