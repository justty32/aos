技能：
aos-inbox：Read and handle the agent mailbox in wf/inbox (letters other agents sent, such as REQUEST or REPORT), then move each letter to a final state. Use when asked to check the mailbox, when another agent says it sent mail, or at session start when wf/inbox has letters. （看信箱、收信、回信、辦信）
aos-test：Run the proto7-2 test suite (all tests, one folder, or tests whose name matches a pattern) inside a systemd scope and report the exit code. Use after changing proto7-2 code, before handing work over, or when asked to check that nothing broke. （跑測試、全套測試、確認沒壞）
wf-lint：Check the wf/ documentation tree for broken links, broken anchors, oversize files, big lists that belong in data files, and leftover placeholders. Use after editing, moving, or splitting markdown files under wf/, or before committing doc changes. （檢查文檔、壞連結、錨點、佔位）

收到的信：
---
from: you
to: bob
status: REQUEST
at: 2026-10-09T18:57:48.110907+08:00
reply-to: /tmp/aos-longtask.avjslz2y/you/inbox
id: you-20261009T185748-d4feb23a67b4
re: 
---
# 附錄：算各隊人均產出

## 做了什麼
請算各隊人均產出（交付項數 ÷ 人數），列成表，並說哪隊最高。
- I5：交付 12 項，3 人
- RV：交付 8 項，人數（還沒拿到）
- FL：交付 4 項，2 人
- B5：交付 9 項，3 人；另一份名單寫 B5 交付 6 項
總交付項數（另一份統計）：30 項


## 產出（檔案路徑 / commit / 分支）
無

## 沒做到、或證據不足的部分
無

## 需要對方或使用者決定的事
無
