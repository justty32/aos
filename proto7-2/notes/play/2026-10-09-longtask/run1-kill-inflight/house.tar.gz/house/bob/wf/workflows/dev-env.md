# dev-env — 開發環境、指令、外部工具

[WORKFLOWS](../WORKFLOWS.md)｜[INDEX](../INDEX.md)

這台機器上要能開發需要什麼、怎麼裝、跑什麼指令；外部工具設定與 env var 也收在這裡。

**何時用**：fresh clone、換機器、裝不起來、忘了指令、要加一個外部工具或環境變數。
**何時不用**：驗證 / 測試怎麼跑 → [testing](testing.md)；程式碼慣例 → [common/conventions](common/conventions.md)。

## Done when

- 照「流程（fresh clone 後）」走完，`（未定：冒煙指令，如 npm run build）` 回傳 0。
- 下面三張表沒有空欄；要使用者親自做的（帳號、授權、金鑰）在 [WAIT_USER](../WAIT_USER.md) 各佔一行。

## 流程（fresh clone 後）

1. （未定：取得完整原始碼，如 git submodule update --init）
2. （未定：安裝依賴，如 npm ci）
3. （未定：設定 env var：複製 .env.example → .env，填下方「外部工具與 env var」表的值）
4. （未定：跑一次冒煙指令確認裝好了，如 npm run build）

## 指令表

| 做什麼 | 指令 | 備註 |
|--------|------|------|
| 安裝依賴 | `（未定：npm ci）` | （未定：何時要重跑） |
| build | `（未定：npm run build）` | |
| 跑起來 | `（未定：npm run dev）` | （未定：port / 進入點） |
| lint / format | `（未定：npm run lint）` | |

驗證與測試指令不列這裡——連同「誰跑」一起在 [testing](testing.md)。

## 外部工具與 env var

| 名稱 | 用途 | 怎麼取得 / 設定 |
|------|------|----------------|
| `（未定：工具名）` | （未定：用途） | （未定：安裝方式與版本要求） |
| `（未定：ENV_VAR）` | （未定：用途） | （未定：放哪、預設值；金鑰不進 repo） |

需要帳號、付費、授權才能取得的：守鐵律 2（授權來源），並在 [WAIT_USER](../WAIT_USER.md) 記一行。

## 交接

- 環境就緒要開工 → [feature-dev](feature-dev/README.md)；先確認驗證跑得動 → [testing](testing.md)。
- 同一個裝機坑第二次撞到 → [common/gotchas](common/gotchas.md)。
