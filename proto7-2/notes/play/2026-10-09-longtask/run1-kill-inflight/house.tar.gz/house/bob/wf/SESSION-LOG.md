# SESSION-LOG — 進度（只列 open）

[INDEX](INDEX.md)｜等使用者的另記 [WAIT_USER](WAIT_USER.md)

**寫入時機**：
1. **開始**多步驟工作前先寫一行 open（不是做完才寫）；硬中斷時本檔才有「進行中」。
2. **每次 commit 後**更新或刪除該行。
3. 條目格式：`- [工作流] 一句 open 狀態 → 下一步 / 連結`；完成即刪，歷史交給 git log，決策落到 [workflows/decisions.md](workflows/decisions.md)。

> 膨脹就拆：過大就開 `session_logs/` 按工作流拆檔＋index（照 [STRUCTURE](STRUCTURE.md)）。

## 最新進度
- [brain] 信 you-20261009T185219-d3ce3a783357：已寫第 6 節「代理開銷」；下一回合寫第 7 節「記憶」。（做完第 6 回合）→ 下回合接著做

（目前無）

## 各工作流 session-log

| 工作流 | session-log | open 摘要 |
|--------|-------------|----------|

