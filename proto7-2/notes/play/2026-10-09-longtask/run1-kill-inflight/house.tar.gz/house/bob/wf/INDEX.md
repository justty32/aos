# INDEX — bob 專案地圖

bob = **aos node「bob」的 agent 工作區（aos7-wfnode init 建立）**。本檔只描述**頂層**：每列一句話＋連結；目錄內部複雜就放它自己的 README / INDEX。

## Repo 佈局

| 路徑 | 內容 |
|------|------|
| `handoffs/` | 續行點：每天一份 `handoffs/<日期>/STATE.md`，[NEXT-SESSION](handoffs/NEXT-SESSION.md) 指最新一份 |
| `workflows/` | 工作流（派發見 [WORKFLOWS.md](WORKFLOWS.md)；共享區 [workflows/common/](workflows/common/README.md)）|
| `.claude/commands/` | slash 指令適配層（可選）。Claude Code 為例：只讀專案根的這層，非侵入式佈局也留在根；沒有 slash 機制的工具忽略本目錄，直接跑 `tools/wf-lint.sh` |
| `tools/` | kernel 工具：`wf-lint.sh`（檢查）、`tabledb.py`（資料檔 CRUD／連結）、`find_big_lists.py`、`fix_moved_links.py`；非侵入式佈局在 `wf/tools/`；資料檔契約見 [workflows/common/data-files.md](workflows/common/data-files.md) |
| `ROSTER.md`、`line-claims.json` | 誰是誰（[ROSTER](ROSTER.md)）與誰能寫哪裡（領地表，資料檔）；由 mail 包填 |
| `inbox/` | agent 之間的信件收件匣：頂層＝未處理、`done/`＝已處理；使用方式 [workflows/inbox/](workflows/inbox/README.md) |
| `tools/` | inbox 腳本：`inbox_send.sh`（原子投遞一封信）、`inbox_read.sh`（唯讀列出未處理的信）；升級五通道後另加 `inbox_mail.sh`、`inbox_poll.sh`、`inbox_team.sh`、`notify_watch.sh`、`test_inbox.sh` |
<!-- wf-insert:INDEX -->

## 頂層文件

| 檔案 | 角色 |
|------|------|
| [WORKFLOWS.md](WORKFLOWS.md) | 派發器：意圖 → 工作流入口 |
| [STRUCTURE.md](STRUCTURE.md) | 結構整理參考（被動）：分層、膨脹即拆、四級成長、archive、工作流形式 |
| [SESSION-LOG.md](SESSION-LOG.md) | 我的 open 進度 |
| [WAIT_USER.md](WAIT_USER.md) | 等使用者親自做 / 驗證的事 |
