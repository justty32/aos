# ROSTER — 導航

身份聲明的正本在 [workflows/inbox/ROSTER.md](workflows/inbox/ROSTER.md)；誰能寫哪裡是資料檔 line-claims.json（wf-table/1）。
