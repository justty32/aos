技能：
aos-inbox：Read and handle the agent mailbox in wf/inbox (letters other agents sent, such as REQUEST or REPORT), then move each letter to a final state. Use when asked to check the mailbox, when another agent says it sent mail, or at session start when wf/inbox has letters. （看信箱、收信、回信、辦信）
aos-test：Run the proto7-2 test suite (all tests, one folder, or tests whose name matches a pattern) inside a systemd scope and report the exit code. Use after changing proto7-2 code, before handing work over, or when asked to check that nothing broke. （跑測試、全套測試、確認沒壞）
wf-lint：Check the wf/ documentation tree for broken links, broken anchors, oversize files, big lists that belong in data files, and leftover placeholders. Use after editing, moving, or splitting markdown files under wf/, or before committing doc changes. （檢查文檔、壞連結、錨點、佔位）

挑到的技能 aos-test：
---
name: aos-test
description: Run the proto7-2 test suite (all tests, one folder, or tests whose name matches a pattern) inside a systemd scope and report the exit code. Use after changing proto7-2 code, before handing work over, or when asked to check that nothing broke. （跑測試、全套測試、確認沒壞）
---

# aos-test：跑 proto7-2 的測試

在 repo 根目錄跑（`S`＝這個 skill 的資料夾；掛載給任務時是 `mnt/skill-aos-test`）。一律包 systemd scope（限程序數與時間，跑壞了不拖垮整台機器）：

```sh
bash $S/scripts/run.sh                       # 全套（約 5 分鐘）
bash $S/scripts/run.sh modules/skills/tests  # 只跑一個資料夾（相對 proto7-2/）
bash $S/scripts/run.sh -k restart            # 只跑名字含 restart 的
```

- 退出碼 0＝全綠、1＝有失敗；回報時給測試數與退出碼。
- 全機同時最多 3 份全套：跑全套前先 `pgrep -fc run_all.py`，≥3 就等。
- 測試清單與慣例見 proto7-2/tests/README.md。


這是第 7 回合（最多 40）。前幾回合（最近 8 回合）：
第 1 回合：已寫第 1 節；下一回合寫第 2 節「範圍」。｜成果：一、目標。本週試營運要驗證 AI 能否使用自己的工作簿（wf），跨回合完成長任務。驗收成果是一份 12 節的《aos 試營運週報》。
第 2 回合：已寫第 2 節「範圍」；下一回合寫第 3 節「進度」。｜成果：二、範圍。本週試營運涵蓋一個 node（bob）、一位使用者（you）及一個 LiteLLM 端點，不連接外部服務。
第 3 回合：已寫第 3 節「進度」；下一回合寫第 4 節「測試」。｜成果：三、進度。13 隊中，9 隊已交件、2 隊正在執行、2 隊尚未開始。目前仍有 4 隊未交件。
第 4 回合：已寫第 4 節「測試」；下一回合寫第 5 節「效率」。｜成果：四、測試。I5 隊回報全套測試共 1000 項，結果全綠。
第 5 回合：已寫第 5 節「效率」；下一回合寫第 6 節「代理開銷」。｜成果：五、效率。結算到 step 結束的時間從 3.34 秒降至 2.71 秒，但尚未達到 1.5 秒的目標。
第 6 回合：已寫第 6 節「代理開銷」；下一回合寫第 7 節「記憶」。｜成果：六、代理開銷。每次呼叫的前置內容約 1644 token，其中約 1620 token 是代理自帶的系統提示。

收到的信：
---
from: you
to: bob
status: REQUEST
at: 2026-10-09T18:52:19.145444+08:00
reply-to: /tmp/aos-longtask.odcgycyn/you/inbox
id: you-20261009T185219-d3ce3a783357
re: 
---
# 寫週報：aos 試營運報告 12 節，分 13 回合做完（每回合寫一節，第 13 回合交全文）

## 做了什麼
請照下面 12 節的材料寫一份《aos 試營運週報》。每回合只寫一節（每節 2～4 句、不超過 150 字），用「繼續：」交這一節；12 節都寫完後，最後一回合用「回信：」交 12 節齊全的全文。材料彼此有對不上的地方，寫到時照實標出「待確認」，不要自己挑一個。

1. 目標：讓 AI 用自己的工作簿（wf）跨回合做長任務；本週驗收是一份 12 節的報告。
2. 範圍：一個 node（bob）、一個人（you）、一個 LiteLLM 端點；不連外部服務。
3. 進度：13 隊中 9 隊已交件，2 隊在跑，2 隊還沒開。
4. 測試：全套測試 1000 項全綠（I5 隊報）。
5. 效率：結算到 step 結束從 3.34 秒降到 2.71 秒，目標 1.5 秒未達。
6. 代理開銷：每次呼叫前置約 1644 token，其中約 1620 是代理自帶的系統提示。
7. 記憶：工作簿超過門檻會自動整理，舊原文封存可找回。
8. 技能：node 有 3 本技能，每封信開始時在本機挑一本，不花 AI 呼叫。
9. 可靠性：FL 隊報 llmcall／up 還有 3 個偶發紅測試，其中 1 個查明是產品 bug。
10. 新手：QUICKSTART 新手試用 Haiku 7.0 分、luna 8.8 分（滿分 10）。
11. 風險：proxy 會把一段回覆拆成多個 choice；已修讀取方式，但上游設定沒動。
12. 下週：把長任務實跑結果寫成報告、清掉 59 個舊 worktree、做一張給使用者的進度圖。


## 產出（檔案路徑 / commit / 分支）
無

## 沒做到、或證據不足的部分
無

## 需要對方或使用者決定的事
無
