# routines — 常規事務（固定循環的例行）

[WORKFLOWS](../WORKFLOWS.md)｜[INDEX](../INDEX.md)

記「在某個**時機 / 週期**下該做的事」，並在 [tick](tick.md) 心跳時把到期的做掉。清單就在本檔。

**何時用**：① **登記**——你說「這是常規事務，幫我加進 routine」「登記例行」；② **執行**——[tick](tick.md) 心跳叫起本檔。
**何時不用**：臨時、指定時刻、做一次就沒了的 → [schedule](schedule.md)。重活（深度巡檢、調查）不在心跳裡跑。

## Done when

- **登記**：[routines.json](../routines.json) 多一列，name、every、inst 非空。
- **執行**：到期項做完，且間隔登記表該列「上次執行」已改成今天。

## 流程

### A. 登記（使用者請求時）

1. 問清三件事：**什麼時機 / 多久一次**、**誰做**（我 / agent）、**做什麼**。
2. 用 `aos7-routines add --every` 寫入 [routines.json](../routines.json)。
3. 回一句確認。**不當場做**（那是心跳的事）。

### B. 執行（tick 心跳叫起時）

1. **判當地時間**：`TZ='Asia/Taipei' date '+%F %A %H:%M'`。（Windows 見本包 README 踩坑。）
2. 到期由 aos tick 判，對照 [routines.json](../routines.json) 的執行證據。
3. **到期就做**——守**鐵律 2（授權來源）**：使用者親自登記在本清單的項目即有授權；唯讀的直接做；不可逆的即使登記了，情況有變也先問。
4. **間隔項做完 → 更新該列「上次執行」**。判定是重活的就記一行 open、另開 session，不在心跳裡跑。
5. 沒到期的略過。不推外部通知：到期就當場做、當場說。

## 間隔登記表（live）

已抽到 [../routines.json](../routines.json)（0 列）；由 routines 包（`aos7-routines add --every`）寫，到期由 aos tick 判。

- name：唯一名稱
- every：正整數加 r/s/m/h/d
- inst：要跑的目標路徑
- last_round：上次回合
- last_time：上次 ISO 本地時間
- last_code：結束碼或 running

## 交接

- 到期項卡在使用者 → [WAIT_USER](../WAIT_USER.md) 一行；跨 session 的未完進度 → [SESSION-LOG](../SESSION-LOG.md) 一行 open。
- 一次性的定時請求 → [schedule](schedule.md)。做常規事務時撞到的坑 → [common/gotchas](common/gotchas.md)。
